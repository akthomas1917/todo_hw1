# todo_hw1
A raw (i.e. vanilla) JavaScript todo list management Web application. Front-end only.
