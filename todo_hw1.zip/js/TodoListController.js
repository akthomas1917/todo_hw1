'use strict'
/**
 * TodoListController.js
 * 
 * This file provides responses for all user interface interactions.
 * 
 * @author McKilla Gorilla
 * @author ?
 */
class TodoListController {
    /**
     * The constructor sets up all event handlers for all user interface
     * controls known at load time, meaning the controls that are declared 
     * inside index.html.
     */
    constructor() {
        // SETUP ALL THE EVENT HANDLERS FOR EXISTING CONTROLS,
        // MEANING THE ONES THAT ARE DECLARED IN index.html

        // FIRST THE NEW LIST BUTTON ON THE HOME SCREEN
        this.registerEventHandler(TodoGUIId.HOME_NEW_LIST_BUTTON, TodoHTML.CLICK, this[TodoCallback.PROCESS_CREATE_NEW_LIST]);

        // THEN THE CONTROLS ON THE LIST SCREEN
        this.registerEventHandler(TodoGUIId.LIST_HEADING, TodoHTML.CLICK, this[TodoCallback.PROCESS_GO_HOME]);
        this.registerEventHandler(TodoGUIId.LIST_NAME_TEXTFIELD, TodoHTML.KEYUP, this[TodoCallback.PROCESS_CHANGE_NAME]);
        this.registerEventHandler(TodoGUIId.LIST_OWNER_TEXTFIELD, TodoHTML.KEYUP, this[TodoCallback.PROCESS_CHANGE_OWNER]);
        this.registerEventHandler("trash", TodoHTML.CLICK, this[TodoCallback.PROCESS_TRASH_CLICK]);
        this.registerEventHandler("yes", TodoHTML.CLICK, this[TodoCallback.PROCESS_TRASH_CLICK_YES]);
        this.registerEventHandler("no", TodoHTML.CLICK, this[TodoCallback.PROCESS_TRASH_CLICK_NO]);        
    }

    /**
     * This function helps the constructor setup the event handlers for all controls.
     * 
     * @param {TodoGUIId} id Unique identifier for the HTML control on which to
     * listen for events.
     * @param {TodoHTML} eventName The type of control for which to respond.
     * @param {TodoCallback} callback The callback function to be executed when
     * the event occurs.
     */
    registerEventHandler(id, eventName, callback) {
        // GET THE CONTROL IN THE GUI WITH THE CORRESPONDING id
        let control = document.getElementById(id);

        // AND SETUP THE CALLBACK FOR THE SPECIFIED EVENT TYPE
        control.addEventListener(eventName, callback);
    }

    /**
     * This function responds to when the user changes the
     * name of the list via the textfield.
     */
    processChangeName() {
        let nameTextField = document.getElementById(TodoGUIId.LIST_NAME_TEXTFIELD);
        let newName = nameTextField.value;
        let listBeingEdited = window.todo.model.listToEdit;
        window.todo.model.updateListName(listBeingEdited, newName);
    }

    processChangeOwner() {
        let ownerTextField = document.getElementById(TodoGUIId.LIST_OWNER_TEXTFIELD);
        let newOwner = ownerTextField.value;
        let listBeingEdited = window.todo.model.listToEdit;
        window.todo.model.updateListOwner(listBeingEdited, newOwner);
    }

    trashclick() {
        document.getElementById("verify").style.visibility = "visible";
    }

    trashclickyes() {
        window.todo.model.removeList(window.todo.model.listToEdit);
        window.todo.model.goHome();
        document.getElementById("verify").style.visibility = "hidden";

    }

    trashclickno() {
        document.getElementById("verify").style.visibility = "hidden";
    }

    processEditItem() {
        //console.log("okkkkkkkk");
    }

    processMoveItemUp(itemIndex) {
        console.log("up arrow has been clicked");
        itemIndex = parseInt(itemIndex);

        //console.log(window.todo.model.listToEdit); //list before swap

        if(itemIndex > 0)
        {
            //console.log(itemIndex);
            //console.log(itemIndex-1)
            window.todo.model.swap(itemIndex, itemIndex-1)
        }
    }

    processMoveItemDown(itemIndex) {
        console.log("down arrow has been clicked");
        itemIndex = parseInt(itemIndex);

        var listLength = window.todo.model.listToEdit.items.length;
        
        console.log(itemIndex);
        console.log(listLength);

        if(itemIndex < listLength-1)
        {
            //console.log(itemIndex);
            //console.log(itemIndex+1)
            window.todo.model.swap(itemIndex, itemIndex+1);
        }
    }

    processDeleteItem(itemIndex) {
        console.log("delete button has been clicked");
        itemIndex = parseInt(itemIndex);

        var listBeingEdited = window.todo.model.listToEdit.items;
        console.log(listBeingEdited[itemIndex]);

        listBeingEdited.splice(itemIndex, 1);

        //window.todo.view.loadListData(listBeingEdited);
        window.todo.view.loadListData(window.todo.model.listToEdit);
    }

    processCreateNewItem() {
        console.log("create new item button has been clicked");

        document.getElementById("addItemScreen").style.visibility = "visible";
    }

    thisbetterwork() {
        console.log("yerrrrrrrrrrrrrrrrrr");
    }


    /**
     * This function is called when the user requests to create
     * a new list.
     */
    processCreateNewList() {
        // MAKE A BRAND NEW LIST
        window.todo.model.loadNewList();

        // CHANGE THE SCREEN
        window.todo.model.goList();
    }

    /**
     * This function responds to when the user clicks on a link
     * for a list on the home screen.
     * 
     * @param {String} listName The name of the list to load into
     * the controls on the list screen.
     */
    processEditList(listName) {
        // LOAD THE SELECTED LIST
        window.todo.model.loadList(listName);

        // CHANGE THE SCREEN
        window.todo.model.goList();
    }

    /**
     * This function responds to when the user clicks on the
     * todo logo to go back to the home screen.
     */
    processGoHome() {
        window.todo.model.goHome();
    }

    /**
     * This function is called in response to when the user clicks
     * on the Task header in the items table.
     */
    processSortItemsByTask() {
        // IF WE ARE CURRENTLY INCREASING BY TASK SWITCH TO DECREASING
        if (window.todo.model.isCurrentItemSortCriteria(ItemSortCriteria.SORT_BY_TASK_INCREASING)) {
            window.todo.model.sortTasks(ItemSortCriteria.SORT_BY_TASK_DECREASING);
        }
        // ALL OTHER CASES SORT BY INCREASING
        else {
            window.todo.model.sortTasks(ItemSortCriteria.SORT_BY_TASK_INCREASING);
        }
    }

    /**
     * This function is called in response to when the user clicks
     * on the Status header in the items table.
     */
    processSortItemsByStatus() {
        // IF WE ARE CURRENTLY INCREASING BY STATUS SWITCH TO DECREASING
        if (window.todo.model.isCurrentItemSortCriteria(ItemSortCriteria.SORT_BY_STATUS_INCREASING)) {
            window.todo.model.sortTasks(ItemSortCriteria.SORT_BY_STATUS_DECREASING);
        }
        // ALL OTHER CASES SORT BY INCRASING
        else {
            window.todo.model.sortTasks(ItemSortCriteria.SORT_BY_STATUS_INCREASING);
        }
    }












}